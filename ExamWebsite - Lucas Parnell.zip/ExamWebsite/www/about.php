<?php
    include_once "../libraries/boilerplate.php";
    echo $blade->run("about", array("page"=>"about"));

?>
