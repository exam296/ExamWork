
@extends('layouts.nonpersonal')
 
@section('title', 'About')

@section('content')

    <div class="container mt-4 py-4 mw-100 mh-100 w-75 h-75">
        <h3 class="display-6 ">About Us</h3>
        <p class="lead"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus magna ex, malesuada id sapien et, sollicitudin imperdiet odio. Maecenas risus quam, efficitur et augue ac, accumsan porta libero. Sed maximus sem id nulla pellentesque facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam laoreet porttitor ex. Nunc sagittis fringilla elit vitae consequat. Suspendisse lobortis vehicula elit, egestas dictum ipsum. Cras a pulvinar eros. Morbi nec diam in nisi euismod bibendum. Morbi a malesuada dui. Vivamus eu nisi erat. Morbi imperdiet purus vel ultricies consequat. In quis lorem sem. Aenean tempor molestie orci eget vestibulum. Suspendisse at tellus nec arcu pharetra suscipit non sagittis elit. </p>
    </div>


@stop